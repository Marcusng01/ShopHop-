1. Run ShopHop!.exe
2. Enter item to look for in search bar
3. Slide the CAPTCHA slider if Lazada detects unusual traffic.
4. Wait for webscraper to scrape information from Shoppee, Lazada and Wowshop
5. Close the browser and console when done.
*ShopHop! can be visited manually by entering "http://127.0.0.1:5000" in any browser as long as the ShopHop! app console is still open.